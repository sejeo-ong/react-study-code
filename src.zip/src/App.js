import logo from './logo.svg';
import './App.css';
import Routes from './Routes/Routes';

function App() {
  return (
    <div className="App">
      <Routes></Routes>
    </div>
  );
}

export default App;
