const Movie = () => {
    return(
        <div>
            영화
        </div>
    );
}

export default Movie;